# Student Database Management System

A MySQL-based DBMS Project Based Learning (PBL) project that organizes student details, departments, courses, enrollments/marks, and fee payments in five related tables.

## Features
- Five relational tables: `Department`, `Student`, `Course`, `Enrollment`, and `Fee_Payment`
- Primary keys, foreign keys, unique constraints, and a marks range check
- Sample data for testing
- SQL examples using `WHERE`, `ORDER BY`, `GROUP BY`, `HAVING`, `JOIN`, subqueries, and aggregate functions
- CRUD examples for adding, updating, and deleting records

## Requirements
- MySQL Server 8.x (or a compatible MySQL version)
- MySQL Workbench or another MySQL client

## How to run
1. Open MySQL Workbench and connect to your local MySQL server.
2. Run `sql/01_create_tables.sql`.
3. Run `sql/02_insert_sample_data.sql`.
4. Run `sql/03_queries.sql` to explore the example reports.
5. Read `sql/04_crud_examples.sql` before uncommenting any data-changing statements.

Run the files in the order listed above. `01_create_tables.sql` drops and recreates the project's tables, so do not run it against a database containing data you want to keep.

## Database relationships
- One Department can have many Students.
- One Department can have many Courses.
- Students and Courses have a many-to-many relationship implemented through Enrollment.
- One Student can have many Fee_Payment records.

## Repository structure
```text
Student-Database-Management-System/
├── README.md
├── docs/
│   └── DBMS_PBL_Documentation.pdf
└── sql/
    ├── 01_create_tables.sql
    ├── 02_insert_sample_data.sql
    ├── 03_queries.sql
    └── 04_crud_examples.sql
```

## Notes
- Sample records are for academic demonstration only.
- The SQL is written for MySQL. The original report specifies MySQL and MySQL Workbench.
- Some query output values may differ if you change the sample records.
